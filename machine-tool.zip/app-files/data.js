var APP_DATA = {
  "scenes": [
    {
      "id": "0-machinetool",
      "name": "MachineTool",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "yaw": 0.10018706816030942,
        "pitch": 0.09202003052506313,
        "fov": 1.3225881469915988
      },
      "linkHotspots": [],
      "infoHotspots": [
        {
          "yaw": -0.0032817913147979993,
          "pitch": -0.0565259835801335,
          "title": "MachineIntro",
          "text": ""
        },
        {
          "yaw": 0.8416799756524647,
          "pitch": -0.06479513295830053,
          "title": "MachineTool1",
          "text": "Text"
        },
        {
          "yaw": 1.55568241460419,
          "pitch": -0.056156048641227585,
          "title": "MachineTool2",
          "text": "Text"
        },
        {
          "yaw": 2.4014112119700037,
          "pitch": -0.047890732058490926,
          "title": "MachineTool3",
          "text": "Text"
        },
        {
          "yaw": -3.1262405479715873,
          "pitch": -0.04389069457185002,
          "title": "MachineTool4",
          "text": "Text"
        },
        {
          "yaw": -2.2467759461317147,
          "pitch": -0.042919452042397666,
          "title": "MachineTool5",
          "text": "Text"
        },
        {
          "yaw": -1.2208925272571314,
          "pitch": -0.038318233329867724,
          "title": "MachineTool6",
          "text": "Text"
        }
      ]
    }
  ],
  "name": "Machine Tool",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
